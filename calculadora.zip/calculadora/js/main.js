let operacionActual = '';
let operacionAnterior = '';
let operacion = undefined;

function agregarNumero(numero) {
    operacionActual += numero;
    actualizarResultado();
}

function operar(op) {
    if (operacionActual === '') return;
    if (operacionAnterior !== '') {
        calcular();
    }
    operacion = op;
    operacionAnterior = operacionActual;
    operacionActual = '';
}

function calcular() {
    let resultado;
    const anterior = parseFloat(operacionAnterior);
    const actual = parseFloat(operacionActual);
    
    if (isNaN(anterior) || isNaN(actual)) return;

    switch (operacion) {
        case '+':
            resultado = anterior + actual;
            break;
        case '-':
            resultado = anterior - actual;
            break;
        case '*':
            resultado = anterior * actual;
            break;
        case '/':
            resultado = anterior / actual;
            break;
        default:
            return;
    }
    operacionActual = resultado;
    operacion = undefined;
    operacionAnterior = '';
    actualizarResultado();
}

function borrar() {
    operacionActual = '';
    operacionAnterior = '';
    operacion = undefined;
    actualizarResultado();
}

function actualizarResultado() {
    document.getElementById('resultado').value = operacionActual;
}